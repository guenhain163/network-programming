# C-chatroom

> A simple chat room in C.

## Executing members include:
1. Nguyễn Thị Hạnh - 20194552
2. Phạm Quang Hà - 20194546
3. Lê Thanh Giang - 20194541

## Environment

- macOS, Ubuntu
- Unix Socket
- POSIX Thread Library

## Run

```
make
./server.out
./client.out
```

